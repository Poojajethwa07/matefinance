const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 5000; // Change the port if needed

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Configure Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: 'gmail', // Or any other email service
  auth: {
    user: 'ashtamtechnologies@gmail.com', // Replace with your email
    pass: 'vksq zgrj bhka ibhw'   // Replace with your email password or app-specific password
  }
});

// API route for sending email
app.post('/send-email', (req, res) => {
  const { name, email, contact, occupation, city } = req.body;

  const mailOptions = {
    from: email,
    to: 'ashtamtechnologies@gmail.com', 
    cc: 'pjethwa0709@gmail.com',
    subject: `New Contact Form Submission from ${name}`,
    html: `
      <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; padding: 20px; border-radius: 8px; background-color: #ffffff; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); padding: 20px;">
          <h2 style="color: #0066cc; text-align: center;">New Contact Form Submission</h2>
          <div style="padding: 15px; background-color: #f9f9f9; border-radius: 5px;">
              <div style="display: flex; align-items: center; padding: 10px; background-color: #eeeeee; border-radius: 5px; border-left: 5px solid #0066cc; margin-bottom: 8px;">
                  <strong style="color: #000; min-width: 80px;">Name:</strong> <span>${name}</span>
              </div>
              <div style="display: flex; align-items: center; padding: 10px; background-color: #eeeeee; border-radius: 5px; border-left: 5px solid #0066cc; margin-bottom: 8px;">
                  <strong style="color: #000; min-width: 80px;">Email:</strong> <span>${email}</span>
              </div>
              <div style="display: flex; align-items: center; padding: 10px; background-color: #eeeeee; border-radius: 5px; border-left: 5px solid #0066cc; margin-bottom: 8px;">
                  <strong style="color: #000; min-width: 80px;">Contact:</strong> 
                  <a href="tel:${contact}" style="color: #0066cc; text-decoration: underline; margin-left: 5px;">${contact}</a>
              </div>
              <div style="display: flex; align-items: center; padding: 10px; background-color: #eeeeee; border-radius: 5px; border-left: 5px solid #0066cc; margin-bottom: 8px;">
                  <strong style="color: #000; min-width: 80px;">Occupation:</strong> <span>${occupation}</span>
              </div>
              <div style="display: flex; align-items: center; padding: 10px; background-color: #eeeeee; border-radius: 5px; border-left: 5px solid #0066cc; margin-bottom: 8px;">
                  <strong style="color: #000; min-width: 80px;">City:</strong> <span>${city}</span>
              </div>
          </div>
          <p style="text-align: center; color: #666; margin-top: 20px;">Thank you for your submission. We will get back to you shortly.</p>
      </div>
    `,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Error sending email:", error);
      return res.status(500).json({ error: 'Mail not sent. Please try again later!' });
    }
    res.status(200).json({ message: 'Email sent successfully!' });
  });
});


// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
